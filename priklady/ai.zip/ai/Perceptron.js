
// perceptron object construction function
function Perceptron(no, learningRate = 0.00001) {

 // set initials
 this.learnc = learningRate;
 this.bias = 1;                                            // the one more value after all input values (eg for input pair x-y there would be third, formula a*x + b*y + c*bias > 0) (considering case without bias, if eg "x" and "y" would be zero, formula 0 + 0 never will be > 0 and perceptron everytime undesired, even if meant to be desired)

 // compute random weights
 this.weights = [];
 for (let i = 0; i <= no; i++) {                           // +1 weight for bias (díky "<=" místo "<" )
   this.weights[i] = Math.random() * 2 - 1;
 }

 // one cycle of train - get the inputs, perform action (based on actual weights), get the result (guessing), compare result with desired result, improve weights
 this.train = function(inputs, desired) {
   let guess = this.activate(inputs);
   let error = desired - guess;
   if (error) {
     for (let i = 0; i < inputs.length; i++) {
       this.weights[i]+= this.learnc * error * inputs[i];
     }
   }
 }

 // activate (action performed based on actual weights)
 this.activate = function(inputs) {
   inputs.push(this.bias);                                 // bias added to inputs
   let sum = 0;
   for (let i = 0; i < inputs.length; i++) {
     sum += inputs[i] * this.weights[i];
   }
   if (sum > 0) {return 1} else {return 0}
 }

}



