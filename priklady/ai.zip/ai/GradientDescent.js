
// trainer object construction function
function Trainer(xArray, yArray) {
 this.xArr = xArray;
 this.yArr = yArray;
 this.points = this.xArr.length;
 this.learnc = 0.000001;
 this.weight = 0;                                // for line formula "y = w*x + b" this is the "w"
 this.bias = 1;                                  // for line formula "y =  w*x + b" this is the "b"
 this.cost;                                      // mean square error (mse)

 // train
 this.train = function train (nTimes) {
   for (let i = 0; i < nTimes; i++) {
     this.updateWeights();
   }
   this.cost = this.costCount();
 }

 // cost count
 this.costCount = function() {
   total = 0;
   for (let i = 0; i < this.points; i++) {
     total += (this.yArr[i] - (this.weight * this.xArr[i] + this.bias)) **2;   // mse = 1/n* ∑ from i=1 to n [y[i] - (w*x[i] + b) ]^2 
   }
   return total / this.points;
 }

 // update weights
 this.updateWeights = function() {
   let wx;
   let w_deriv = 0;
   let b_deriv = 0;
   for (let i = 0; i < this.points; i++) {
     wx = this.yArr[i] - (this.weight * this.xArr[i] + this.bias);
     w_deriv += -2 * wx * this.xArr[i];
     b_deriv += -2 * wx;
   }
   this.weight -= (w_deriv / this.points) * this.learnc;                       // Δ mse / Δ weight = -2/n* ∑ from i=1 to n [y[i] - (w*x[i] + b) ], then multiplied by this.learnc
   this.bias -= (b_deriv / this.points) * this.learnc;                         // Δ mse / Δ bias = -2/n* ∑ from i=1 to n [y[i] - (w*x[i] + b) ], then multiplied by this.learnc
 }

}



