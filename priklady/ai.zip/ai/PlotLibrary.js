
// plotter object construction function
function XYPlotter(id) {
 this.canvas = document.getElementById(id);
 this.ctx = this.canvas.getContext("2d");
 this.xMin = 0;
 this.yMin = 0;
 this.xMax = this.canvas.width;
 this.yMax = this.canvas.height;
 this.ctx.font = "16px Verdana";
 this.scaleX = 1;
 this.scaleY = 1;

 // transform xy
 this.transformXY = function() {
   this.ctx.transform(1, 0, 0, -1, 0, this.canvas.height);
 }

 // transform max
 this.transformMax = function(newMaxX, newMaxY) {
   this.scaleX = this.canvas.width / newMaxX;
   this.scaleY = this.canvas.height / newMaxY;
 };

 // plot line
 this.plotLine = function(x0, y0, x, y, color) {
   this.ctx.moveTo(x0 *this.scaleX, y0 *this.scaleY);
   this.ctx.lineTo(x *this.scaleX, y *this.scaleY);
   this.ctx.strokeStyle = color;
   this.ctx.stroke();
 }

 // plot point
 this.plotPoint = function(x, y, color, radius = 3) {
   this.ctx.fillStyle= color;
   this.ctx.beginPath();
   this.ctx.ellipse(x *this.scaleX, y *this.scaleY, radius, radius, 0, 0, Math.PI * 2);
   this.ctx.fill();
 }

 // plot points
 this.plotPoints = function(n, xArr, yArr, color, radius = 3) {
   for (let i = 0; i < n; i++) {
     this.ctx.fillStyle = color;
     this.ctx.beginPath();
     this.ctx.ellipse(xArr[i] *this.scaleX, yArr[i] *this.scaleY, radius, radius, 0, 0, Math.PI * 2);
     this.ctx.fill();
   }
 }


 // plot rectangle
 this.plotRectangle = function(x, y, w, h) {
   this.ctx.strokeRect(x *this.scaleX, y *this.scaleY, w, h);
 }

 // plot circle
 this.plotCircle = function(x, y, r) {
   this.ctx.beginPath();
   this.ctx.arc(x *this.scaleX, y *this.scaleY, r, 0, 2 * Math.PI);
   this.ctx.stroke();
 }

 // plot text
 this.plotText = function(x, y, text) {
   this.ctx.fillText(text, x *this.scaleX, y *this.scaleY);
 }

}



