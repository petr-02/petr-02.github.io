
function A(){
    console.log(5);
}

A()