
const express = require('express')
const app = express()
const port = 3000


app.get('/text/', (req, res) => {
  res.send( {proměnná:"abcd", proměnná2:true} )	
})

app.get('/', (req, res) => {
  res.sendFile('c:/xprogramovani/adresar_s_html/index.html' )
})
app.get('/index.js', (req, res) => {
  res.sendFile('c:/xprogramovani/adresar_s_html/index.js' )
})
app.get('/index.css', (req, res) => {
  res.sendFile('c:/xprogramovani/adresar_s_html/index.css' )
})


app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})

