
let a:string="hello"; a=5;

