
const checkboxes= document.querySelectorAll( "input[type='checkbox']" );
const examples= document.querySelectorAll( ".example" );

checkboxes.forEach((checkbox)=>{
 checkbox.addEventListener("change", ()=>{
   examples.forEach((example)=>{
     example.classList.toggle( checkbox.id )
   })
 })
})

