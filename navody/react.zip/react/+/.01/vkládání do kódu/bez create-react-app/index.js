
'use strict'

// react komponenta 1
const nazev_komponenty_1 = React.createElement("h2", {}, "hello")


// vložení react komponenty 1 do html
const HTMLElmDOMObject1 = document.getElementById("root1")
const reactRoot1 = ReactDOM.createRoot( HTMLElmDOMObject1 )
reactRoot1.render( nazev_komponenty_1 )



