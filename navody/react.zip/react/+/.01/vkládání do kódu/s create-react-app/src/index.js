
import React from 'react';
import ReactDOM from 'react-dom/client';

// react komponenta
const nazev_komponenty = <h2>hello</h2>			// resp. bez "jsx" --> const nazev_komponenty = React.createElement("h2", {}, "hello")

// vložení react komponenty do html
const HTMLElmDOMObject = document.getElementById("root")
const reactRoot = ReactDOM.createRoot( HTMLElmDOMObject )
reactRoot.render( nazev_komponenty )

