
'use strict'

// React class komponenta
class ReactClassKomponenta extends React.Component {
  render(){
    return React.createElement("h1", {}, "hello class")
  }
}
// React function komponenta
function ReactFunctionKomponenta (){
  return React.createElement("h1", {}, "hello function")
}


// vložení React class komponenty do html
const HTMLElmDOMObject1 = document.getElementById("root1")
const reactRoot1 = ReactDOM.createRoot( HTMLElmDOMObject1 )
reactRoot1.render( React.createElement(ReactClassKomponenta) )

// vložení React function komponenty do html
const HTMLElmDOMObject2 = document.getElementById("root2")
const reactRoot2 = ReactDOM.createRoot( HTMLElmDOMObject2 )
reactRoot2.render( React.createElement(ReactFunctionKomponenta) )




