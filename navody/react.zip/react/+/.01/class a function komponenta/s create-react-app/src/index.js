
import React from 'react';
import ReactDOM from 'react-dom/client';


// react class komponenta
class NazevClassKomponenty extends React.Component {
    render(){ return <h1> hello class </h1>; }					// bez jsx --> return React.createElement("h1", {}, "hello class")
}
// react function komponenta
function NazevFunctionKomponenty () { return <h1> hello function </h1>; }	// bez jsx --> return React.createElement("h1", {}, "hello function")


// vložení react class komponenty do html
const HTMLElmDOMObject1 = document.getElementById("root1")
const reactRoot1 = ReactDOM.createRoot( HTMLElmDOMObject1 )
reactRoot1.render( <NazevClassKomponenty/> )					// bez jsx --> reactRoot1.render( React.createElement(NazevClassKomponenty) )

// vložení react function komponenty do html
const HTMLElmDOMObject2 = document.getElementById("root2")
const reactRoot2 = ReactDOM.createRoot( HTMLElmDOMObject2 )
reactRoot2.render( <NazevFunctionKomponenty/> )					// bez jsx --> reactRoot2.render( React.createElement(NazevFunctionKomponenty) )




