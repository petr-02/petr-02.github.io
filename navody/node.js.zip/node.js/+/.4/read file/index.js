
// soubor se spustí příkazem "node index.js" (psaným v příkazovém řádku v místě, kde je i "index.js")
// do prohlížeče se napíše "http://localhost:3000" (co pošle request serveru); server přečte obsah "soubor.html" a vrátí jej jako response prohlížeči; prohlížeč pak (že je v odpovědi "header" "text/html") zobrazí získaný obsah naformátovaný jako html  (pro "text/plain" by zobrazil obsah včetně html tagů)

const http = require('http');
const fs = require('fs');

const hostname = '127.0.0.1';
const port = 3000;


const server = http.createServer((req, res) => {
  fs.readFile( "./soubor.html", function(err,data){
    res.writeHead(200, {'Content-Type': 'text/html'});
    res.write(data);
    res.end();
  });
});

server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});

