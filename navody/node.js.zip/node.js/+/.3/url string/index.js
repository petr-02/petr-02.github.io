
// soubor se spustí příkazem "node index.js" (psaným v příkazovém řádku v místě, kde je i "index.js")
// poté se do prohlížeče vloží adresa "http://localhost:3000/?year=2017&month=July"
// server vrátí response "2017 July"

const http = require('http');
const { URL } = require('url');

const hostname = '127.0.0.1';
const port = 3000;


const server = http.createServer((req, res) => {
  res.writeHead(200, {'Content-Type': 'text/plain'});

  const url = new URL(req.url , `http://${req.headers.host}` )
  const year = url.searchParams.get('year');
  const month = url.searchParams.get('month');
  const txt = `${year} ${month}`;
  res.end( txt );
});

server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});






