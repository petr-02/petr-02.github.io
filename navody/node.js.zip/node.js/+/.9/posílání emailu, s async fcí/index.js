
// soubor se spustí příkazem "node index.js" (psaným v příkazovém řádku v místě, kde je i "index.js")
// změní se emailová adresa odesílatele "nazev@seznam.cz" (je v kódu dvakrát)
// změní se emailová adresa příjemce "komu@seznam.cz"
// změní se heslo "password"
// před použitím musí být nainstalován modul "nodemailer" (příkazový řádek projektu --> "npm i nodemailer")

"use strict";
const nodemailer = require("nodemailer");

const transporter = nodemailer.createTransport({
  host: "smtp.seznam.cz",
  port: 465,
  secure: true,
  auth: { user:'nazev@seznam.cz', pass:'password' }
});

async function main() {
  const info = await transporter.sendMail({
    from: 'nazev@seznam.cz',
    to: 'komu@seznam.cz',
    subject: 'predmet emailu',
    text: 'text emailu'
  });
  console.log("message sent: " + info.messageId);
}
main().catch(console.error);

