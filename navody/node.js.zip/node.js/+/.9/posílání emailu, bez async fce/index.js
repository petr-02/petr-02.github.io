
// soubor se spustí příkazem "node index.js" (psaným v příkazovém řádku v místě, kde je i "index.js")
// změní se emailová adresa odesílatele "nazev@seznam.cz" (je v kódu dvakrát)
// změní se emailová adresa příjemce "komu@seznam.cz"
// změní se heslo "password"
// před použitím musí být nainstalován modul "nodemailer" (příkazový řádek projektu --> "npm i nodemailer")

const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  host: "smtp.seznam.cz",
  port: 465,
  secure: true,
  auth: { user:'nazev@seznam.cz', pass:'password' }
});

const mailOptions = {
  from: 'nazev@seznam.cz',
  to: 'komu@seznam.cz',
  subject: 'predmet emailu',
  text: 'text emailu'
};

transporter.sendMail( mailOptions, function(err, info){
  if(err){
    console.log(err)
  } else {
    console.log('email sent: ' + info.response);
  }
});

