
// varianta 1
exports.proměnná1 = function(){ return new Date().toLocaleTimeString() }
exports.proměnná2 = "hello world"

// varianta 2
/*
const proměnná1 = function(){ return new Date().toLocaleTimeString() }
const proměnná2 = "hello world"
module.exports = {proměnná1, proměnná2}
*/

