
const http = require('http');
const nazevPromenneObjektuModulu = require( "./nazevSouboruModulu.js" )

const hostname = '127.0.0.1';
const port = 3000;


const server = http.createServer((req, res) => {
  res.writeHead(200, {'Content-Type': 'text/plain'});
  res.write( "aktualni cas: " + nazevPromenneObjektuModulu.proměnná1() + "\n" );	// "\n" tj. "escape sequence" pro enter / nový řádek
  res.write( "zprava: " + nazevPromenneObjektuModulu.proměnná2 + "\n" );
  res.end( "konec" );      // "hiiii\n asdf" 
});

server.listen(port, hostname, () => {
  console.log(`server is running at http://${hostname}:${port}/`);
});

