
console.log( "------------------------" )

console.log( module )

console.log( "------------------------" )

const q0=require("./js0.js");
const q1=require("./js1.js");

console.log( module )

console.log( "------------------------" )



