
const q00=require("./js0.0.js");

module.exports=5



