
navigator.geolocation.getCurrentPosition( callbackFceSuccess );

function callbackFceSuccess( param_position ){			// fce success je asi volána, je-li získáno alespoň: latitude, longitude, accuracy
 const latitude = param_position.coords.latitude;
 const longitude = param_position.coords.longitude;
 const accuracy = param_position.coords.accuracy;
 const altitude = param_position.coords.altitude			// na stolních počítačích asi obvykle null (nemají gps)
 const altitudeAccuracy = param_position.coords.altitudeAccuracy	// na stolních počítačích asi obvykle null (nemají gps)

 document.body.innerHTML =
   "latitude: " + latitude + "<br>" +
   "longitude: " + longitude + "<br>" +
   "accuracy (latitude a longitude): " + accuracy + "&nbsp;m" + "<br>" +
   "altitude: " + (altitude ? altitude + "&nbsp;m" : "n/a") + "<br>" +			// podmínka pro případ, že je altitude "null"
   "altitude accuracy: " + (altitudeAccuracy ? altitudeAccuracy + "&nbsp;m" : "n/a")	// podmínka pro případ, že je altitudeAccuracy "null"
}

