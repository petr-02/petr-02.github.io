
<button onclick="this.style.display='none'">click</button>

