
===========================================================================================
verze 1 (kód JS musí být načten až po elementu <button>, tj. script musí být vložen za, nebo kód upraven, viz verze .2) (bez úpravy "getElementById("A5")" nenajde "A5")
===========================================================================================

=v html=
<button id="A5">klik</button>

=v JS=
document.getElementById("A5").addEventListener("click", AaA);	// stanoví, že nastane-li událost "click", spustí fci AaA; a to v dokumentu, elementu "A5" (tj. <button>)

function AaA(event) {						// funguje i bez "event", ale správně je asi s
alert(event.clientX);
}

===========================================================================================
verze 2 (script může být vložen kdekoliv)
===========================================================================================

=v html=
<button id="A5">klik</button>

=v JS=
window.addEventListener("DOMContentLoaded", AAA);		// stanoví jiný event, že je-li "DOM content načten", spustí se AAA; tj. kód uvnitř AAA se spustí v době, kdy je již načten <button> (a jiné elementy html...)
function AAA() {

 document.getElementById("A5").addEventListener("click", AaA);	// stanoví, že nastane-li událost "click", spustí se fce AaA; a to v dokumentu, elementu "A5" (tj. <button>)

 function AaA(event) {						// funguje i bez "event", ale správně je asi s
 alert(event.clientX);
 }

}



