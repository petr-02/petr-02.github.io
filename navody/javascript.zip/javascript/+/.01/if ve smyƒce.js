
// tato smyčka (odděluje kód pro if_ano a ne_if_ano)
for (let x=1;x<3;x++){
 if (x<2){
  alert(x + " je asi 1" + " smyčka 1")
 } else {
  alert(x + " je asi 2" + " smyčka 1")
 }
}

// dává stejný výsledek jako tato (odděluje kód pro if_ano a ne_if_ano tím, že if_ano provede svůj kód a přeskočí zbytek smyčky; tím může za "if" být již jen situace ne_if_ano)
for (let x=1;x<3;x++){
 if (x<2){
  alert(x + " je asi 1" + " smyčka 2");
  continue
 }
 alert(x + " je asi 2" + " smyčka 2")
}

// dává také stejný výsledek, ale nezjednodušuje tolik zápis
for (let x=1;x<3;x++){
 if (x<2){} else {
  alert(x + " je asi 2" + " smyčka 3");
  continue
 }
 alert(x + " je asi 1" + " smyčka 3")
}

// resp. s opačnou podmínkou (prohodí se tím kód if_ano a ne_if_ne)
for (let x=1;x<3;x++){
 if (x>=2){
  alert(x + " je asi 2" + " smyčka 4");
  continue
 }
 alert(x + " je asi 1" + " smyčka 4")
}

// ---------------------------------

/* nejde ovšem pro následující (musel by se společný kód přidat do obou "if")
for (let x=1;x<3;x++){
 if (x<2){
  alert(x + " je asi 1" + " smyčka 1")
 } else {
  alert(x + " je asi 2" + " smyčka 1")
 }
 alert("kód společný pro if_ano a ne_if_ano")
}
*/





