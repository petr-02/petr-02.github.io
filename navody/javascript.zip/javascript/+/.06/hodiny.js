
===========================================================================================
vytvoření hodinek 00:00:00 pm/am
===========================================================================================

-------
v html
-------
<form name="hod">
<input name="iny" type="text" size="12">
</form>

-------
v JS
-------

AA()
function AA(){
var a=new Date()			// vytvoření instance objektu "Date"; bez parametrů v "()" je pro aktuální čas
var hodina=a.getHours()			// proměnná "hodina" = aktuální hodina
var minuta=a.getMinutes()		// "minuta"
var sekunda=a.getSeconds()		// "sekunda"

var hodiny = ""						// deklarace proměnné "hodiny" --> "String"
								// následující 4 podmínky lze nahradit: if(hodina<10){hodiny+= "0"+hodina} else if(hodina<=12){hodiny+= hodina} else if(hodina<22){hodiny+= "0"+(hodina-12)} else{hodiny+= hodina-12}
hodiny+= (hodina<10) ? "0"+hodina : ""				// uplynulo-li "0-9" hodin, zobraz "00-09"
hodiny+= (hodina>=10 & hodina<13) ? hodina : ""			// "10-12", zobraz "10-12"  (ve skutečnosti 12tá hodina je už 0tá pm)
hodiny+= (hodina>12 & hodina<22) ? "0"+(hodina-12) : ""		// "13-21", zobraz "01-09"
hodiny+= (hodina>=22) ? hodina-12 : ""				// "22-23", zobraz "10-11"

hodiny+= ((minuta<10) ? ":0" : ":") + minuta	// je-li minut "0-9", zobraz ":0x", jinak ":xx"
hodiny+= ((sekunda<10)? ":0" : ":") + sekunda	// také tak pro sekundu
hodiny+= (hodina>=12) ? " pm" : " am"		// 12h a více zobraz " pm", jinak " am"

document.hod.iny.value = hodiny			// zobraz hodnotu proměnné "hodiny" do html (do formuláře, jeho textového pole)
setTimeout("AA()",1000)				// vyčkej sekundu a pak spusť funkci znovu
}




